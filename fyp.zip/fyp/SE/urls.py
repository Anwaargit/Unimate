
from django.urls import path
from .views import landingPage,signUp

urlpatterns = [
   path('',landingPage.as_view(),name='home'),
   path('registration/',signUp.as_view(),name='registration')
]
