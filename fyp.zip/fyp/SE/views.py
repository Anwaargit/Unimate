from django.shortcuts import render
from django.views.generic import TemplateView,CreateView
from django.contrib.auth.forms import UserCreationForm

from .form import NewUserCreation 
from django.urls import reverse_lazy

# Create your views here.
class landingPage(TemplateView):
    template_name='index.html'

    
class signUp(CreateView):
    form_class = NewUserCreation
    template_name='registration/signUp.html'
    success_url = reverse_lazy("home") 
    
    
