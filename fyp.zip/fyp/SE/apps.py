from django.apps import AppConfig


class SeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SE'
