from .models import Profile

from django import forms




class NewImageForm(forms.ModelForm):
    image = forms.ImageField(widget=forms.FileInput)
    class Meta:
        model = Profile
        fields=['contactNumber','address','image']