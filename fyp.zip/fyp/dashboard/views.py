from typing import Any
from django.db.models.base import Model as Model
from django.db.models.query import QuerySet
from django.forms.models import BaseModelForm
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,UpdateView,CreateView,View,DetailView
from django.contrib.auth.views import PasswordChangeView
from django.urls import reverse_lazy
from .models import Profile

from .forms import NewImageForm
# Create your views here.



class Dashboard(DetailView):
    template_name = "dashboardfiles/main.html"
    model = Profile
    context_object_name = "profile"
    def get_object(self, queryset=None):
        return Profile.objects.get(username=self.request.user)
    
class Change_Student_Password(PasswordChangeView):
    template_name = "dashboardfiles/changePassword.html"
    success_url=reverse_lazy('dashboard')
    
class Notifications(TemplateView):
    template_name='dashboardfiles/notifications.html'
    
class RecommendationSystem(TemplateView):
    template_name='dashboardfiles/recomSystem.html'
    
class cityBaseSearch(TemplateView):
    template_name='dashboardfiles/cityBaseSearch.html'
    
class Discusstions(TemplateView):
    template_name='dashboardfiles/discussions.html'









class preCreateProfile(TemplateView):
    template_name='dashboardfiles/profile/createProfile_pre.html'



class EditProfile(UpdateView):
    template_name='dashboardfiles/profile/editProfile.html'
    success_url=reverse_lazy('dashboard')
    form_class = NewImageForm    
    
    def get_object(self, queryset=None):
        return Profile.objects.get(username=self.request.user)

class CreateProfileView(CreateView):
    template_name='dashboardfiles/profile/createProfile.html'
    model=Profile
    fields=['contactNumber','address','image']
    success_url=reverse_lazy('dashboard')
    
    def form_valid(self,form):
        form.instance.username=self.request.user
        return super().form_valid(form)

class profileRedirectView(View):
    
    def get(self, request,*args,**kwargs):
            user_profile = Profile.objects.filter(username=request.user).first()
            if user_profile:
                return redirect("dashboard")
            else:
                return redirect("createProfile_pre")
            
