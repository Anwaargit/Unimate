
from django.urls import path
from .views import preCreateProfile,Dashboard,profileRedirectView,Change_Student_Password,Notifications,RecommendationSystem,cityBaseSearch,Discusstions,EditProfile,CreateProfileView

urlpatterns = [
   path('',profileRedirectView.as_view(),name='main_dashboard'),
   path('profile/',Dashboard.as_view(),name='dashboard'),

   path('createProfile_pre/',preCreateProfile.as_view(),name="createProfile_pre"),
   path("changepassword/",Change_Student_Password.as_view(),name="changepassword"),
    path("notifications/",Notifications.as_view(),name="notifications"),
    path('recommendation/',RecommendationSystem.as_view(),name='recommendation'),
    path('citybasesearch/',cityBaseSearch.as_view(),name='citybasesearch'),
    path('discussions/',Discusstions.as_view(),name='discussions'),
    path('editProfile/',EditProfile.as_view(),name='editProfile'),
     path('createProfile/',CreateProfileView.as_view(),name='createProfile')
]
