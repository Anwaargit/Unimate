from django.contrib.auth.decorators import login_required

def profile_img(request):
    if request.user.is_authenticated:
        if request.user.profile:
            return {'profile_img': getattr(request.user.profile, 'image',None)}
        else:
            return {'profile_img':None}
    else:
        return {'profile_img':None}